package wpk.account;
/**
 *
 * @author Sathipp
 */
public enum AccountStatus {
    ACTIVEB,
    FULL,
    CANCELED,
    BLACKLISTED
}
