package wpk.service;
import wpk.account.Account;
/**
 *
 * @author Sathipp
 */
public class PremiumMemberAccount {
    
}
