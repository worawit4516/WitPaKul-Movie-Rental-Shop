package wpk.service;
/**
 *
 * @author Sathipp
 */
public abstract class EmployeeAccount {
    
}
