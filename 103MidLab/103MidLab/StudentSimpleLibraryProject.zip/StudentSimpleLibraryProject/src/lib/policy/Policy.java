package lib.policy;
public interface Policy {
  public static final int MAX_LENDING_BOOKS = 5;
  public static final int MAX_LENDING_DAYS = 10;
  public static final int FINE_PER_DAY =50;
  public static final int MAX_OVER_DUE=3;
}
